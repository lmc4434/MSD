#ifndef __NUCLEO476_CLOCK_H
#define __NUCLEO476_CLOCK_H

#include "stm32l476xx.h"

void System_Clock_Init(void);

#endif /* __NUCLEO476_CLOCK_H */
